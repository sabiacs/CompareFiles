package com.comparefolder.CompareApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompareApplicationTests {

	@Test
	void contextLoads() {
	}

}
